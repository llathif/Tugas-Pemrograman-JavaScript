// books.js
const books = [
  {
    id: 1,
    title: "Pulang",
    author: "Tere Liye",
    year: 2015,
    description: "Sebuah kisah tentang perjalanan pulang, melalui pertarungan demi pertarungan, untuk memeluk erat semua kebencian dan rasa sakit.",
    image: "https://cdn.gramedia.com/uploads/items/pulang_tere_liye.jpeg"
  },
  {
    id: 2,
    title: "Pergi",
    author: "Tere Liye",
    year: 2018,
    description: "Kelanjutan dari novel 'Pulang', Bujang melanjutkan petualangannya ke berbagai belahan dunia untuk menemukan jawaban atas misteri keluarganya.",
    image: "https://cdn.gramedia.com/uploads/items/pergi_tere_liye.jpeg"
  },
  {
    id: 3,
    title: "Bumi",
    author: "Tere Liye",
    year: 2014,
    description: "Kisah petualangan Raib, seorang remaja dengan kekuatan istimewa, yang menemukan dunia paralel dan persahabatan sejati.",
    image: "https://cdn.gramedia.com/uploads/items/9786020332956_Bumi-New-Cover.jpg"
  },
  {
    id: 4,
    title: "Rindu",
    author: "Tere Liye",
    year: 2014,
    description: "Mengambil latar perjalanan haji di tahun 1938, novel ini mengisahkan tentang perjalanan spiritual dan pengampunan di atas sebuah kapal uap.",
    image: "https://leksikabookstore.com/uploads/63c11a2538ee9_20230113154525-1.jpg"
  },
  {
    id: 5,
    title: "Hujan",
    author: "Tere Liye",
    year: 2016,
    description: "Sebuah cerita tentang cinta dan persahabatan di dunia masa depan yang canggih, di mana ingatan bisa dihapus dan cuaca bisa diatur.",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQiG5-mHc-znGdlLoUA13snqfje6eTMKadjEA&s"
  },
  {
    id: 6,
    title: "Negeri Para Bedebah",
    author: "Tere Liye",
    year: 2012,
    description: "Novel action-economy yang menceritakan seorang konsultan keuangan hebat yang harus menyelamatkan sebuah bank dari kehancuran sistematis.",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcShP5t8lo58PvH9GBdLn5NxzWWS_qbYaUX5Gg&s"
  },
  {
    id: 7,
    title: "Bulan",
    author: "Tere Liye",
    year: 2015,
    description: "Buku kedua dari serial 'Bumi', petualangan Raib, Seli, dan Ali berlanjut ke Klan Bulan untuk mencari sekutu melawan Tamus yang jahat.",
    image: "https://imgv2-2-f.scribdassets.com/img/document/717898990/original/0512772e00/1?v=1"
  },
  {
    id: 8,
    title: "Tentang Kamu",
    author: "Tere Liye",
    year: 2016,
    description: "Kisah seorang pengacara muda yang harus mengungkap misteri kehidupan seorang wanita tua yang baru saja meninggal untuk menyelesaikan warisannya.",
    image: "https://cdn.gramedia.com/uploads/items/9786239554569.jpg"
  },
  {
    id: 9,
    title: "Si Anak Cahaya",
    author: "Tere Liye",
    year: 2018,
    description: "Menceritakan kisah masa kecil Nurmas, seorang anak dengan imajinasi liar dan semangat yang menyala-nyala di sebuah lembah pedalaman.",
    image: "https://img.lazcdn.com/g/p/48bb7f30fb779c2538b41b0f709a817c.jpg_720x720q80.jpg_.webp"
  },
  {
    id: 10,
    title: "Daun yang Jatuh Tak Pernah Membenci Angin",
    author: "Tere Liye",
    year: 2010,
    description: "Kisah cinta yang tulus dan rumit antara seorang gadis bernama Tania dan seorang pria yang telah menjadi malaikat pelindungnya sejak kecil.",
    image: "https://www.static-src.com/wcsstore/Indraprastha/images/catalog/full//catalog-image/98/MTA-117905425/brd-44261_daun-yang-jatuh-tak-pernah-membenci-angin-tere-liye_full01-23164533.jpg"
  },
];

export default books;