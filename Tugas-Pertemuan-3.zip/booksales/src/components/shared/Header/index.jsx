import { Link, NavLink } from "react-router-dom";
import './Header.css';

export default function Header() {
    return (
        <>
            <header className="custom-header d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4">
                <div className="col-md-3 mb-2 mb-md-0">
                    <a href="/" className="d-inline-flex align-items-center link-body-emphasis text-decoration-none">
                        <i className="fa-solid fa-book fa-2xl logo-icon"></i>
                        <span className="ms-2 fs-4 logo-text">Bookstore</span>
                    </a>
                </div>

                <ul className="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
                    <li><NavLink to="/" className="nav-link px-2 nav-link-custom">Home</NavLink></li>
                    <li><NavLink to="/books" className="nav-link px-2 nav-link-custom">Book</NavLink></li>
                    <li><NavLink to="/tim" className="nav-link px-2 nav-link-custom">Team</NavLink></li>
                    <li><NavLink to="/kontaks" className="nav-link px-2 nav-link-custom">Contact</NavLink></li>
                </ul>

                <div className="col-md-3 text-end">
                    <Link to="/login">
                        <button type="button" className="btn btn-outline-primary me-2 custom-btn">Login</button>
                    </Link>
                    <Link to="/register">
                        <button type="button" className="btn btn-primary custom-btn">Register</button>
                    </Link>
                </div>
            </header>
        </>
    )
}