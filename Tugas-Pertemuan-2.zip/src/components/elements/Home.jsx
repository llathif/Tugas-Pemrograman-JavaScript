import Footer from "../shared/Footer";
import Header from "../shared/Header";
import Hero from "../shared/Hero";
import ProductList from "../shared/ProductList";
import Tim from "../shared/Tim";
import Kontak from "../shared/Kontak";

export default function Home(){
    return(
        <>
        <Header/>
        <Hero/>
        <ProductList/>
        <Tim/>
        <Kontak/>
        <Footer/>
        </>
    )
}