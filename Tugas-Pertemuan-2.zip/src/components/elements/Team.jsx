import Footer from "../shared/Footer";
import Header from "../shared/Header";
import Tim from "../shared/Tim";

export default function Team(){
    return(
        <>
        <Header/>
        <Tim/>
        <Footer/>
        </>
    )
}