import Footer from "../shared/Footer";
import Header from "../shared/Header";
import Kontak from "../shared/Kontak";

export default function Contact(){
    return(
        <>
        <Header/>
        <Kontak/>
        <Footer/>
        </>
    )
}