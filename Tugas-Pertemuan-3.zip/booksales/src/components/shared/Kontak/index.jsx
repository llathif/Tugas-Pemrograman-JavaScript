export default function Kontak(){
    return(
        <>
            <div className="container col-xl-10 col-xxl-8 px-4 py-5">
            <div className="row align-items-center g-lg-5 py-5">
              {/* Kolom kiri */}
              <div className="col-lg-7 text-center text-lg-start">
                <h1 className="display-4 fw-bold lh-1 text-body-emphasis mb-3">
                  Hubungi Kami
                </h1>
                <p className="col-lg-10 fs-4">
                  Punya pertanyaan atau masukan? Jangan ragu untuk menghubungi kami melalui formulir di samping. Tim kami akan segera merespons Anda.
                </p>

                <div className="mt-5">
                  <h4 className="fw-bold mb-3">Atau Hubungi Langsung</h4>
                  <div className="d-flex flex-column flex-md-row gap-3">
                    <a
                      href="https://wa.me/62895339652000"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn btn-success btn-lg d-flex align-items-center justify-content-center"
                    >
                      <i className="fa-brands fa-whatsapp me-2"></i> WhatsApp
                    </a>
                    <a
                      href="https://getbootstrap.com/docs/5.3/examples/"
                      className="btn btn-danger btn-lg d-flex align-items-center justify-content-center"
                    >
                      <i className="fa-solid fa-envelope me-2"></i> Email
                    </a>
                  </div>
                </div>
              </div>
              {/* Kolom kanan */}
              <div className="col-md-10 mx-auto col-lg-5">
                <form className="p-4 p-md-5 border rounded-3 bg-body-tertiary">
                  <div className="form-floating mb-3">
                    <input
                      type="email"
                      className="form-control"
                      id="floatingInput"
                      placeholder="name@example.com"
                    />
                    <label htmlFor="floatingInput">Alamat Email</label>
                  </div>
                  <div className="form-floating mb-3">
                    <input
                      type="text"
                      className="form-control"
                      id="floatingSubject"
                      placeholder="Subjek"
                    />
                    <label htmlFor="floatingSubject">Subjek</label>
                  </div>
                  <div className="form-floating mb-3">
                    <textarea
                      className="form-control"
                      id="floatingTextarea"
                      placeholder="Pesan Anda"
                      style={{ height: "100px" }}
                    ></textarea>
                    <label htmlFor="floatingTextarea">Pesan</label>
                  </div>
                  <button className="w-100 btn btn-lg btn-primary" type="submit">
                    Kirim Pesan
                  </button>
                  <hr className="my-4" />
                  <small className="text-body-secondary">
                    Dengan mengirim, Anda menyetujui syarat dan ketentuan kami.
                  </small>
                </form>
              </div>
            </div>
          </div>
        </>
    )
}