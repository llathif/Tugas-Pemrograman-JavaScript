import React, { useState } from 'react';
import styles from "../../../styles/Produk.module.css";
import initialBooksData from "../../../Utils/books.js";

function NewProductList() {
    const [books, setBooks] = useState(initialBooksData);

    const handleAddBook = () => {
        // Identitas buku yang akan ditambahkan.
        const newBook = {
            id: books.length + 1,
            title: "Bumi Manusia",
            author: "Pramoedya Ananta Toer",
            year: 1980,
            description: "Sebuah roman sejarah yang menggambarkan masa-masa awal kebangkitan nasional Indonesia pada awal abad ke-20 melalui mata seorang pemuda Jawa bernama Minke.",
            image: `https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1565658920i/1398034.jpg`
        };
        setBooks([...books, newBook]);
        alert("Buku baru berhasil ditambahkan!");
    };

    return (
        <>
            {/* Bagian Hero Section "Best Seller" */}
            <section className="py-5 text-center container">
                <div className="row py-lg-5">
                    <div className="col-lg-6 col-md-8 mx-auto">
                        <h1 className="fw-light">Best Seller</h1>
                        <p className="lead text-body-secondary">
                            Koleksi buku terlaris pilihan pembaca. Temukan bacaan menarik yang akan memperluas wawasan dan inspirasimu.
                        </p>
                        <p>
                            <a href="#" className="btn btn-primary my-2 m-2">Lihat Semua</a>
                            <a href="#" className="btn btn-secondary my-2">Buku Lain</a>
                        </p>
                    </div>
                </div>
            </section>

            {/* Bagian Daftar Buku Pilihan */}
            <div className={styles.produkContainer}>
                {/* Judul dan tombol */}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                    <h1 className={styles.title}>Daftar Buku</h1>
                    <button onClick={handleAddBook} className={styles.addButton}>
                        Tambah Buku
                    </button>
                </div>
                
                <div className={styles.cardContainer}>
                    {/* Bagian .map() */}
                    {books.map((item) => (
                        <div key={item.id} className={styles.card}>
                            <img src={item.image} alt={item.title} />
                            <div className={styles.cardContent}> {/* Tambahan wrapper untuk teks */}
                                <h3>{item.title}</h3>
                                <p><strong>Penulis:</strong> {item.author}</p>
                                <p><strong>Tahun:</strong> {item.year}</p>
                                <p><strong>Deskripsi:</strong> {item.description}</p>
                            </div>
                            <div className={styles.cardActions}>
                                <button className={styles.btn}>View</button>
                                <button className={styles.btn}>Order</button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </>
    );
}

export default NewProductList;