import Footer from "../shared/Footer";
import Header from "../shared/Header";
import NewProductList from "../shared/NewProduct";
import ProductList from "../shared/ProductList";

export default function Book(){
    return(
        <>
        <Header/>
        <NewProductList />        
        {/* <ProductList/> */}
        <Footer/>
        </>
    )
}