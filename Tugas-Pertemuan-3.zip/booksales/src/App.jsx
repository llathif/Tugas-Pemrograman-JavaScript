import { BrowserRouter, Route, Routes } from 'react-router';
import Home from './components/elements/Home';
import Book from './components/elements/Book';
import Team from './components/elements/Team';
import Contact from './components/elements/Contact';
import Login from './components/pages/auth/login';
import Register from './components/pages/auth/register';

function App() {

  return (
    <>
      <div className="container">
        <BrowserRouter>
          <Routes>
            <Route index element={<Home/>} />
            <Route path="books" element={<Book/>} />
            <Route path="tim" element={<Team/>} />
            <Route path="kontaks" element={<Contact/>} />
            <Route path="login" element={<Login/>} />
            <Route path="register" element={<Register/>} />
          </Routes>
        </BrowserRouter>
      </div>
    </>
  )
}

export default App;