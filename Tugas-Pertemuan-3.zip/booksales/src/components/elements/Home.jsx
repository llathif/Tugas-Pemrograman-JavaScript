import Footer from "../shared/Footer";
import Header from "../shared/Header";
import Hero from "../shared/Hero";
import ProductList from "../shared/ProductList";
import Tim from "../shared/Tim";
import Kontak from "../shared/Kontak";
import NewProductList from "../shared/NewProduct";

export default function Home(){
    return(
        <>
        <Header/>
        <Hero/>
        <NewProductList />
        {/*<ProductList/>*/}
        <Tim/>
        <Kontak/>
        <Footer/>
        </>
    )
}